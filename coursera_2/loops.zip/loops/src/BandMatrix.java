public class BandMatrix {
    public static void main(String[] args) {
        long arg_1 = Integer.parseInt(args[0]);
        long arg_2 = Integer.parseInt(args[1]);

        for (int i = 0; i < arg_1; i++) {
            for (int j = 0; j < arg_1; j++) {
                if (j > 0) {
                    System.out.print(" ");
                }
                if (Math.abs(j - i) > arg_2) {
                    System.out.print("0 ");
                } else {
                    System.out.print("* ");
                }

            }
            System.out.println();
        }

    }

}

