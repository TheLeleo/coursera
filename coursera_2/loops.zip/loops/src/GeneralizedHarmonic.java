public class GeneralizedHarmonic {
    public static void main(String[] args) {
        long num_1 = Integer.parseInt(args[0]);
        long num_2 = Integer.parseInt(args[1]);
        double soma = 0;
        for (int i = 1; i <= num_1; i++) {
            soma += 1 / (Math.pow(i, num_2));
        }
        System.out.print(soma);
    }
}
