public class RandomWalkers {
    public static void main(String[] args) {


        int r = Integer.parseInt(args[0]);
        int attempts = Integer.parseInt(args[1]);
        int x_cords, y_cords, steps;
        boolean walked;
        double total = 0;

        for (int current_attempt = 0; current_attempt < attempts; current_attempt++) {
            x_cords = 0;
            y_cords = 0;
            steps = 0;

            while (Math.abs(x_cords) + Math.abs(y_cords) != r) {
                walked = false;

                double operation = Math.random();

                int calc = Math.abs(x_cords) + Math.abs(y_cords);
                int max_x = r + calc;
                int min_x = (r * -1) - calc;

                int max_y = r + calc;
                int min_y = (r * -1) - calc;


                if (operation <= 0.25 & x_cords < max_x) {
                    x_cords = x_cords + 1;
                    walked = true;
                } else if (operation <= 0.50 & x_cords > min_x) {
                    x_cords = x_cords - 1;
                    walked = true;
                } else if (operation <= 0.75 & y_cords < max_y) {
                    y_cords = y_cords + 1;
                    walked = true;
                } else if (y_cords > min_y) {
                    y_cords = y_cords - 1;
                    walked = true;
                }

                if (walked) {
                    steps += 1;
                }
            }

            total += steps;


        }

        double result = total / attempts;

        System.out.println("average number of steps = " + result);


    }
}
