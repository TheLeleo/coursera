public class RandomWalker {
    public static void main(String[] args) {

        int r = Integer.parseInt(args[0]), x_cords = 0, y_cords = 0, passos = 0;
        boolean andou;

        System.out.println("(" + x_cords + ", " + y_cords + ")");

        while (Math.abs(x_cords) + Math.abs(y_cords) != r) {
            andou = false;

            double operation = Math.random();


            int calc = Math.abs(x_cords) + Math.abs(y_cords);
            int max_x = r + calc;
            int min_x = (r * -1) - calc;

            int max_y = r + calc;
            int min_y = (r * -1) - calc;


            if (operation < .25 & x_cords < max_x) {
                x_cords = x_cords + 1;
                andou = true;
            } else if (operation < .50 & x_cords > min_x) {
                x_cords = x_cords - 1;
                andou = true;
            } else if (operation < .75 & y_cords < max_y) {
                y_cords = y_cords + 1;
                andou = true;
            } else if (y_cords > min_y) {
                y_cords = y_cords - 1;
                andou = true;
            }

            if (andou) {
                passos++;
                System.out.println("(" + x_cords + ", " + y_cords + ")");
            }
        }

        System.out.println("steps = " + passos);
    }

}

