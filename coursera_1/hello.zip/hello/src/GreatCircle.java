public class GreatCircle {
    public static void main(String[] args) {
        double x1 = Math.toRadians(Double.parseDouble(args[0]));
        double y1 = Math.toRadians(Double.parseDouble(args[1]));
        double x2 = Math.toRadians(Double.parseDouble(args[2]));
        double y2 = Math.toRadians(Double.parseDouble(args[3]));

        double x_distance = x2 - x1;
        double y_distance = y2 - y1;

        double a = Math.pow(Math.sin(x_distance / 2), 2) + Math.cos(x1) * Math.cos(x2) * Math.pow(Math.sin(y_distance / 2), 2);

        double angle = Math.toRadians(2 * 6371) * Math.asin(Math.sqrt(a));

        double distance = Math.toDegrees(angle);


        System.out.println(distance + " Kilometers");
    }
}
