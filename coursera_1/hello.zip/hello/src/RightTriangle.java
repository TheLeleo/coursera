public class RightTriangle {
    public static void main(String[] args) {

        long num_1 = Integer.parseInt(args[0]);
        long num_2 = Integer.parseInt(args[1]);
        long num_3 = Integer.parseInt(args[2]);

        long mult_1 = num_1 * num_1;
        long mult_2 = num_2 * num_2;
        long mult_3 = num_3 * num_3;

        System.out.print(num_1 > 0 & num_2 > 0 & num_3 > 0 & (mult_1 + mult_2 == mult_3 || mult_2 + mult_3 == mult_1 || mult_1 + mult_3 == mult_2));
    }
}
